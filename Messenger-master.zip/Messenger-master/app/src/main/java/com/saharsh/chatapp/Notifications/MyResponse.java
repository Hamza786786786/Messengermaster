package com.saharsh.chatapp.Notifications;

public class MyResponse {

    public int success;
}
